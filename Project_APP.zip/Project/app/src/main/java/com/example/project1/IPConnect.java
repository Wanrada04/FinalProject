package com.example.project1;

public final class IPConnect {
    public static final String IP_CONNECT = "192.168.1.45";
    public static final int Barcode_Expire = 1;
}
